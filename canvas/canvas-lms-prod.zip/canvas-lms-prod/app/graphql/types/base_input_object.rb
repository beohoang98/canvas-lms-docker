# frozen_string_literal: true

class Types::BaseInputObject < GraphQL::Schema::InputObject
end
