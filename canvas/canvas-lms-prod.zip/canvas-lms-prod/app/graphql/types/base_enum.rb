# frozen_string_literal: true

class Types::BaseEnum < GraphQL::Schema::Enum
end
